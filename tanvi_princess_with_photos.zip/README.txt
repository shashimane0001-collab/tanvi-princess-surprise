TANVI PRINCESS DAY WEBSITE

Upload ALL FOUR files to the ROOT of your GitHub repository:
- index.html
- memory-one.jpg
- memory-two.jpg
- memory-three.jpg

On GitHub mobile: open your repository > Add file > Upload files > choose all four files > Commit changes.
Keep all files together in the same folder (repository root). Do not upload only index.html, because the photos are separate image files.

Your existing GitHub Pages setup should automatically publish the updated site after the commit. Wait a minute or two, then refresh the live website.
